/*
 * main.c
 *
 * Created: 4/4/2022 5:43:28 PM
 *  Author: Xiangsheng Gu
 */ 

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>

#include "avr.h"
#include "lcd.h"
#include "lcd.c"

typedef struct
{
	int year;
	unsigned char month;
	unsigned char day;
	unsigned char hour;
	unsigned char minute;
	unsigned char second;
	unsigned char editing; // Flag that can be either 0 or 1 
	unsigned char militaryMode; // Flag that can be either 0 or 1 
	unsigned char AM_PM; // Flag that can be either 0 or 1 
	unsigned char nextday;
} DateTime;

int is_pressed(int r, int c)
{
	// Set all 8 GPIOs to N/C
	DDRC = 0;
	PORTC = 0;
	
	// Set r to "0"
	SET_BIT(DDRC, r);
	CLR_BIT(PORTC, r);
	
	// Set c to "w1"
	CLR_BIT(DDRC, c + 4);
	SET_BIT(PORTC, c + 4);
	avr_wait(1);
	
	if (GET_BIT(PINC, c + 4) == 0) //value of c == 0
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int get_key() 
{
	int i, j;
	for (i=0; i < 4; i++) 
	{
		for (j=0; j < 4; j++) 
		{
			if (is_pressed(i, j)) 
			{
				return 4 * i + j + 1;
			}
		}
	}
	return 0;
}

char int_to_char(int key)
{
	// Transform integer to actual character of the key for the functionality purpose.
	switch (key)
	{
		case 1:
			return '0' + key;
		case 2:
			return '0' + key;
		case 3:
			return '0' + key;
		case 4:
			return 'A';
		case 5:
			return '0' + key - 1;
		case 6:
			return '0' + key - 1;
		case 7:
			return '0' + key - 1;
		case 8:
			return 'B';
		case 9:
			return '0' + key - 2;
		case 10:
			return '0' + key - 2;
		case 11:
			return '0' + key - 2;
		case 12:
			return 'C';
		case 13:
			return '*';
		case 14:
			return '0';
		case 15:
			return '#';
		case 16:
			return 'D';
	}
	return '$';
}


void init_dt(DateTime *dt)
{
	dt->year = 2008;
	dt->month = 2;
	dt->day = 28;
	dt->hour = 22;
	dt->minute = 59;
	dt->second = 57;
	dt->editing = 0; // 0 is the default setting: 1 means turn-on and 0 means turn-off.
	dt->militaryMode = 1; // 1 is the default setting: 1 means turn-on and 0 means turn-off.
	dt->AM_PM = 0; // 0 is the default setting: 1 means PM and 0 means AM.
	dt->nextday = 0;
}

void advance_DMY(DateTime *dt)
{
	dt->AM_PM = 0;
	// Increase day and reset hour.
	if (dt->militaryMode == 1)
		dt->hour = 0;
	else
		dt->hour = 12;
	++dt->day;
				
	if (dt->day >= 32 && (dt->month == 1 || dt->month == 3 || dt->month == 5 ||
	dt->month == 7 || dt->month == 8 || dt->month == 10 || dt->month == 12))
	{
		// These months have 31 days.
		// Increase month and reset day.
		dt->day = 1;
		++dt->month;
		if (dt->month >= 13)
		{
			// Increase year and reset month.
			dt->month = 1;
			++dt->year;
		}
	}
	else if (dt->day >= 28 && dt->month == 2)
	{
		// February has either 28 days or 29 days, which depends on if is a leap year.
		if (dt->year % 4 == 0)
		{
			// A leap year, so February has 29 days.
			// Increase month and reset day.
			dt->day = 29;
			if (dt->month >= 13)
			{
				// Increase year and reset month.
				dt->month = 1;
				++dt->year;
			}
		}
		else
		{
			// Not a leap year, so February has 28 days.
			// Increase month and reset day.
			dt->day = 1;
			++dt->month;
			if (dt->month >= 13)
			{
				// Increase year and reset month.
				dt->month = 1;
				++dt->year;
			}
		}
	}
	else if (dt->day >= 31 && (dt->month == 4 ||
	dt->month == 6 || dt->month == 9 || dt->month == 11))
	{
		// These months have 30 days.
		// Increase month and reset day.
		dt->day = 1;
		++dt->month;
		if (dt->month >= 13)
		{
			// Increase year and reset month.
			dt->month = 1;
			++dt->year;
		}
	}	
}

void advance_dt(DateTime *dt)
{
	++dt->second;
	if (dt->second >= 60)
	{
		// Increase minute and reset second.
		dt->second = 0;
		++dt->minute;
		// Repeat process as needed.
		if (dt->minute >= 60)
		{
			// Increase hour and reset minute.
			dt->minute = 0;
			++dt->hour;
			if (dt->militaryMode == 1 && dt->hour >= 24)
			{
				advance_DMY(dt);
			}
			else if (dt->militaryMode == 0 && dt->hour >= 12 && dt->AM_PM == 0)
			{
				// it is 11:59:59 AM
				dt->hour = 12;
				dt->AM_PM = 1;
				// now it is 12:00:00 PM
				advance_dt(dt);
				
			}
			else if (dt->militaryMode == 0 && dt->hour >= 13 && dt->AM_PM == 1)
			{
				// it is 12:59:59 PM
				dt->hour = 1;
				// now it is 01:00:00 PM
				advance_dt(dt);
			}			
			else if (dt->militaryMode == 0 && dt->hour >= 12 && dt->AM_PM == 1)
			{
				// it is 11:59 PM
				dt->hour = 12;
				// now it is 12:00 AM
				advance_DMY(dt);
			}
			else
			{
				advance_DMY(dt);	
			}
		}
	}
}

void print_dt(const DateTime *dt) 
{
	char buf[17];
	char buff[17];
	
	// Print date on top row.
	lcd_pos(0, 0);
	sprintf(buf, "%04d-%02d-%02d", dt->year, dt->month, dt->day);
	
	lcd_puts2(buf);
	// Do similar thing to print time on bottom row.
	lcd_pos(1, 0);
	
	if (dt->militaryMode == 1)
	{
		sprintf(buff, "%02d:%02d:%02d", dt->hour, dt->minute, dt->second);
	}
	else
	{
		if(dt->AM_PM == 0)
			sprintf(buff, "%02d:%02d:%02d AM", dt->hour, dt->minute, dt->second);
		else
			sprintf(buff, "%02d:%02d:%02d PM", dt->hour, dt->minute, dt->second);				
	}
	lcd_puts2(buff);
}


void adjust_dt(DateTime *dt, char actual_key)
{
	switch(actual_key)
	{
		//*****For date*****
		case '*':
		dt->day = (dt->day == 31) ? 1 : dt->day + 1;
		break;
		
		case '7':
		dt->day = (dt->day == 1) ? 31 : dt->day - 1;
		break;
		
		case '0':
		dt->month = (dt->month == 12) ? 1 : dt->month + 1;
		break;
		
		case '8':
		dt->month = (dt->month == 1) ? 12 : dt->month - 1;
		break;
		
		case '#':
		dt->year = (dt->year == 5555) ? 1 : dt->year + 1;
		break;
		
		case '9':
		dt->year = (dt->year == 1) ? 5555 : dt->year - 1;
		break;
		
		//*****Also for time*****

		case '4':
		dt->second = (dt->second == 59) ? 0 : dt->second + 1;
		break;
		
		case '1':
		dt->second = (dt->second == 0) ? 59 : dt->second - 1;
		break;
		
		case '5':
		dt->minute = (dt->minute == 59) ? 0 : dt->minute + 1;
		break;
		
		case '2':
		dt->minute = (dt->minute == 0) ? 59 : dt->minute - 1;
		break;
		
		case '6':
		dt->hour = (dt->hour == 23) ? 0 : dt->hour + 1;
		break;
		
		case '3':
		dt->hour = (dt->hour == 0) ? 23 : dt->hour - 1;
		break;
		
		case 'B':
		// Pressing 'B' will stop editing.
		dt->editing = !dt->editing;
		break;
		
		case 'D':
		// Pressing 'D' will change AM/PM.
		dt->AM_PM = !dt->AM_PM;
		break;
				
		case 'C':
		// Pressing 'C' will change the mode.
		dt->militaryMode = !dt->militaryMode;
		lcd_clr();
		print_dt(dt);
		break;
	}
}

void print_Welcome()
{
	char buf[17];
	char buff[17];
	lcd_pos(0, 0);
	sprintf(buf, "---Welcome---");
	
	lcd_puts2(buf);
	lcd_pos(1, 0);
	sprintf(buff, "Sys is loading");
	lcd_puts2(buff);			
}

void print_Error()
{
	char buf[17];
	char buff[17];
	lcd_pos(0, 0);
	sprintf(buf, "Invaid inputs");
	
	lcd_puts2(buf);
	lcd_pos(1, 0);
	sprintf(buff, "Please try again");
	lcd_puts2(buff);
}

int main() 
{
	avr_init();
	DateTime dt;
	lcd_init();
	init_dt(&dt);
	if (dt.year < 0 || dt.year > 2022 || dt.month < 1 || dt.month > 12 || dt.day < 1 || dt.day > 31 || dt.hour > 24 || dt.minute > 59 || dt.second > 59 
	|| (dt.editing != 0 && dt.editing != 1) || (dt.militaryMode != 0 && dt.militaryMode != 1) || (dt.AM_PM != 0 && dt.AM_PM != 1))
	{
		print_Error();
	}
	lcd_clr();
	print_Welcome();
	avr_wait(1000);
	
	while (1) 
	{
		avr_wait(1000);
		int key;
		char actual_key;
		key = get_key();
		actual_key = int_to_char(key);
		
		if (actual_key == 'A')
		{
			// Pressing 'A' will adjust the time.
			dt.editing = 1;
			while(dt.editing == 1)
			{
				key = get_key();
				actual_key = int_to_char(key);
				lcd_clr();
				avr_wait(500);
				print_dt(&dt);
				adjust_dt(&dt, actual_key);
				if ((dt.hour >= 13 || dt.hour == 0) && dt.militaryMode == 0)
				{
					dt.hour -= 12;
					dt.AM_PM = 1;
				}
				if ((dt.hour < 13 && dt.AM_PM == 1) && dt.militaryMode == 1)
				{
					dt.hour += 12;
					dt.AM_PM = 1;
				}
				avr_wait(500);				
			}
		}
		else
		{
			lcd_clr();
			advance_dt(&dt);
			print_dt(&dt);	
		}
	}
	return 0;
}