/*
 * main.c
 *
 * Created: 4/4/2022 5:43:28 PM
 *  Author: Family
 */ 

#include <xc.h>
#include "avr.h"

int main(void)
{
	SET_BIT(DDRB, 0);
	CLR_BIT(DDRB, 1);
    
	while(1)
    {
        if (GET_BIT(PINB, PB1) == 0)// The Physical button is pressed.
		{
			SET_BIT(PORTB, 0);		// PB1, LED light turns on.
			avr_wait(500);			// The blinking rate is set as 500 ms.
			CLR_BIT(PORTB, 0);		// PB1, LED light turns off.
			avr_wait(500);
		}
		else
		{
			CLR_BIT(PORTB, 0);		//The Physical button is released, so the LED light turns off.
		}
		 
    }
	avr_wait(500);
}