/*
 * main.c
 *
 * Created: 5/3/2022 10:59:26 AM
 *  Author: Xiangsheng
 */ 

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>

#include "avr.h"
#include "lcd.h"
#include "avr.c"
#include "lcd.c"

// Frequency Mapping of notes.
#define A	220.00 
#define As	233.08
#define B	246.94
#define C	261.63
#define Cs	277.18
#define D	293.66
#define Ds	311.13
#define Ee	329.63
#define F	349.23
#define Fs	369.99
#define G	392.00
#define Gs	415.30

// Duration
#define W 2.0
#define H 1.0
#define Q 0.5
#define Ei 0.25

int is_pressed(int r, int c)
{
	// Set all 8 GPIOs to N/C
	DDRC = 0;
	PORTC = 0;
	
	// Set r to "0"
	SET_BIT(DDRC, r);
	CLR_BIT(PORTC, r);
	
	// Set c to "w1"
	CLR_BIT(DDRC, c + 4);
	SET_BIT(PORTC, c + 4);
	avr_wait(1);
	
	if (GET_BIT(PINC, c + 4) == 0) //value of c == 0
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int get_key() 
{
	int i, j;
	for (i=0; i < 4; i++) 
	{
		for (j=0; j < 4; j++) 
		{
			if (is_pressed(i, j)) 
			{
				return 4 * i + j + 1;
			}
		}
	}
	return 0;
}

char int_to_char(int key)
{
	// Transform integer to actual character of the key for the functionality purpose.
	switch (key)
	{
		case 1:
			return '0' + key;
		case 2:
			return '0' + key;
		case 3:
			return '0' + key;
		case 4:
			return 'A';
		case 5:
			return '0' + key - 1;
		case 6:
			return '0' + key - 1;
		case 7:
			return '0' + key - 1;
		case 8:
			return 'B';
		case 9:
			return '0' + key - 2;
		case 10:
			return '0' + key - 2;
		case 11:
			return '0' + key - 2;
		case 12:
			return 'C';
		case 13:
			return '*';
		case 14:
			return '0';
		case 15:
			return '#';
		case 16:
			return 'D';
	}
	return '$';
}

void print_Welcome()
{
	char buf[17];
	char buff[17];
	lcd_pos(0, 0);
	sprintf(buf, "---Welcome---");
	
	lcd_puts2(buf);
	lcd_pos(1, 0);
	sprintf(buff, "Sys is loading");
	lcd_puts2(buff);			
}

void print_Error()
{
	char buf[17];
	char buff[17];
	lcd_pos(0, 0);
	sprintf(buf, "Invaid inputs");
	
	lcd_puts2(buf);
	lcd_pos(1, 0);
	sprintf(buff, "Please try again");
	lcd_puts2(buff);
}


/**************************************** Project 3 ****************************************/
typedef struct 
{
	double freq;
	double duration;
}PlayingNote;


// Sound level
char volume = 1;

PlayingNote DoRaMi[] =
{
	{A, W},	
	{As, W},
	{B, W},
	{C, W},
	{Cs, W},
	{D, W},
	{Ds, W},
	{Ee, W},
	{F, W},
	{Fs, W},
	{G, W},
	{Gs, W},		
	{A, H},
	{As, H},
	{B, H},
	{C, H},
	{Cs, H},
	{D, H},
	{Ds, H},
	{Ee, H},
	{F, H},
	{Fs, H},
	{G, H},
	{Gs, H},
	{A, Q},
	{As, Q},
	{B, Q},
	{C, Q},
	{Cs, Q},
	{D, Q},
	{Ds, Q},
	{Ee, Q},
	{F, Q},
	{Fs, Q},
	{G, Q},
	{Gs, Q},
	{A, Ei},
	{As, Ei},
	{B, Ei},
	{C, Ei},
	{Cs, Ei},
	{D, Ei},
	{Ds, Ei},
	{Ee, Ei},
	{F, Ei},
	{Fs, Ei},
	{G, Ei},
	{Gs, Ei}
};

PlayingNote shooting_stars[] = 
{
	{Ds, W},
	{0, H},
	{Ds, H},
	{Ee, H},
	{0, H},
	{B, Q},
	{0, Q},
	{Gs, Q},
	{Ds, W},
	{0, H},
	{Ds, H},
	{Ee, H},
	{0, H},
	{B, Q},
	{0, Q},
	{Gs, Q},
	{Ds, W},
	{0, H},
	{Ds, H},
	{Ee, H},
	{0, H},
	{B, Q},
	{0, Q},
	{Gs, Q},
	{Ds, W},
	{0, H},
	{Ds, H},
	{Ee, H},
	{0, H},
	{B, Q},
	{0, Q},
	{Gs, Q}
};

PlayingNote I_Wonder[] =
{
	{Cs, H},
	{Ds, H},
	{Fs, H},
	{Ee, H},
	{C, H},
	{A, H},
	{C, H},
	{Ds, H},
	{Cs, H},
	{B, H},
	{D, H},
	{0, H},	
	{D, H},
	{0, H},
	{D, H},	
	{A, H},	
	{G, H},	
	{Ee, H},	
	{D, H},
	{0, H},
	{D, H},
	{0, H}
};

PlayingNote DarkTetris[] =
{
	{Ee, W}, 
	{B, H}, 
	{C, H}, 
	{D, H}, 
	{0, H}, 
	{C, H}, 
	{B, H}, 
	{A, H},
	{0, H}, 
	{A, H}, 
	{C, H}, 
	{Ee, H}, 
	{0, H}, 
	{D, H}, 
	{C, H}, 
	{B, H},
	{0, W}, 
	{C, H}, 
	{D, H}, 
	{0, H}, 
	{Ee, H}, 
	{C, H}, 
	{0, H}, 
	{A, H},
	{0, H}, 
	{A, H}};


// Song length
#define N_0 sizeof(DoRaMi) / sizeof(DoRaMi[0])
#define N_1 sizeof(shooting_stars) / sizeof(shooting_stars[0])
#define N_2 sizeof(I_Wonder) / sizeof(I_Wonder[0])
#define N_3 sizeof(DarkTetris) / sizeof(DarkTetris[0])

void precise_wait(double msec)
{
  TCCR0 = 2;
  while (msec--) 
  {
	  TCNT0 = (unsigned char)(256 - ((XTAL_FRQ)/8) * 0.00001); // seed setting
	  SET_BIT(TIFR, TOV0);
	  WDR();
	  while (!GET_BIT(TIFR, TOV0));
  }
  TCCR0 = 0;
}

void play_note(const PlayingNote* note) 
{
	int key = get_key();
	char actual_key = int_to_char(key);		
	switch(actual_key)
	{			
		case '3':
		// speaker muted
		volume = 0;
		break;
	}
	if (volume != 0)
	{
		int i, k;
		double f = note->freq;
		double d = note->duration;
		double p = 1 / f;
		int TH, TL;
		TH = (p / 2) * 10000;
		TL = TH;
		
		k = d / p;

		for (i = 0; i < k; i++)
		{
			SET_BIT(PORTB, 3);	// Speaker On
			precise_wait(TH);
			CLR_BIT(PORTB, 3);	// Speaker Off
			precise_wait(TL);
		}		
	}
}


void play_song(const PlayingNote song[], int length)
{
	int i;
	if (volume != 0)
	{
		for (i = 0; i < length; i++)
		{
			play_note(&song[i]);
		}
	}
	lcd_clr();
}

int main ()
{
	avr_init();
	lcd_init();
	lcd_clr();
	print_Welcome();
	avr_wait(1000);
	lcd_clr();
	
	SET_BIT(DDRB, 3);
	char buf[17];
	char buff[17];
	
	while (1)
	{
		int key = get_key();
		char actual_key = int_to_char(key);
		switch(actual_key)
		{
			case 'D':
			// play the song
			volume = 1;
			lcd_pos(0, 0);
			sprintf(buf, "Now is playing:");
			lcd_puts2(buf);
			
			lcd_pos(1, 0);
			sprintf(buff, "< DoRaMi >");
			lcd_puts2(buff);
			
			play_song(DoRaMi, N_0);
			break;

			case 'C':
			// play the song
			volume = 1;
			lcd_pos(0, 0);
			sprintf(buf, "Now is playing:");
			lcd_puts2(buf);
			
			lcd_pos(1, 0);
			sprintf(buff, "< Shooting Stars >");
			lcd_puts2(buff);
			play_song(shooting_stars, N_1);
			break;
						
			case 'B':
			// play the song
			volume = 1;
			lcd_pos(0, 0);
			sprintf(buf, "Now is playing:");
			lcd_puts2(buf);
			
			lcd_pos(1, 0);
			sprintf(buff, "< I Wonder >");
			lcd_puts2(buff);
			
			play_song(I_Wonder, N_2);
			break;
			
			case 'A':
			// play the song
			volume = 1;
			lcd_pos(0, 0);
			sprintf(buf, "Now is playing:");
			lcd_puts2(buf);
			
			lcd_pos(1, 0);
			sprintf(buff, "< Dark Tetris >");
			lcd_puts2(buff);
			play_song(DarkTetris, N_3);
			
		}
	}
	return 0;
}
/**************************************** Project 3 ****************************************/